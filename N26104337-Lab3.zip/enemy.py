#### annotation is in big5 if you use it in utf8 please reopen it 
import pygame
import math
import time
import os
#### use the path node PATH_1 ,PATH_2 in setting.py
from settings import PATH_1 ,PATH_2 

#### pygame start
pygame.init()
#### use image
ENEMY_IMAGE = pygame.image.load(os.path.join("images", "enemy.png"))


class Enemy:
    def __init__(self):
        self.width = 40
        self.height = 50
        self.image = pygame.transform.scale(ENEMY_IMAGE, (self.width, self.height))
        self.health = 5
        self.max_health = 10
        self.path = PATH_1
        self.continued_path = PATH_1
        self.path_pos = 0
        self.move_count = 0
        self.stride = 1                           ####set the enemy's stride length
        self.x, self.y = self.path[0]             ####set the enemy's place
        self.wave = 1                             ####to determine the enemy's initial place and which path shoud it go
        self.start = 0                            ####start triger to sure  enemy just initial one time
        self.path_step = 0                        ####to record enemy's path step
        self.counter = 0                          ####to check enemy arrive the relay station
        self.point_a,self.point_b = self.path[0]  ####use to track enemy's path
        
    def draw(self, win):
        # draw enemy
        win.blit(self.image, (self.x - self.width // 2, self.y - self.height // 2))
        # draw enemy health bar
        self.draw_health_bar(win)
        
    def draw_health_bar(self, win):
        ####to sure enemy's health_bar max length is 40
        enemy_health = 40*(self.health/self.max_health) ####to record enemy's health 
        pygame.draw.rect(win, (255, 0, 0), [self.x-20, self.y-30 , 40 , 5])    ####to draw base of health bar with red rect
        pygame.draw.rect(win, (0, 255, 0), [self.x-20, self.y-30 , enemy_health , 5])   ####to draw enemy's health base with green rect
        """
        Draw health bar on an enemy
        :param win: window
        :return: None
        """
        # ...(to be done)
        pass

    def move(self):
        ####use global variable  PATH_1 ,PATH_2
        global PATH_1
        global PATH_2
        #### initial each enemy just one time
        if self.start == 0:
            if self.wave %2 == 1:
                self.path = PATH_1
                path_real = PATH_1
                self.point_a = path_real[0]
                self.point_b = path_real[1]
                self.x, self.y = path_real[0]
                self.start = 1
            else :
                self.path = PATH_2
                path_real = PATH_2
                self.point_a = path_real[0]
                self.point_b = path_real[1]
                self.x, self.y = path_real[0]
                self.start = 1
        else:
            path_real = self.path
        
        ax, ay = self.point_a  # x, y position of point A
        bx, by = self.point_b
        stride = 1
        distance_A_B = math.sqrt((ax - bx)**2 + (ay - by)**2)
        max_count = int(distance_A_B / stride)  # total footsteps that needed from A to B
        
        if self.counter <= max_count:
            unit_vector_x = (bx - ax) / distance_A_B
            unit_vector_y = (by - ay) / distance_A_B
            delta_x = unit_vector_x * stride
            delta_y = unit_vector_y * stride

            # update the coordinate and the counter
            self.x += delta_x
            self.y += delta_y
            self.counter += 1
        #### renew the start node and goal node
        else :
            self.path_step = self.path_step + 1
            self.point_a = path_real[self.path_step]
            self.point_b = path_real[self.path_step + 1]
            self.counter = 0
        # size_1 = len(PATH_1)
        # if counter > size_1:
        #     wave += 1

        
        """
        
        Enemy move toward path points every frame
        :return: None
        """
        # ...(to be done)
        pass


class EnemyGroup:
    def __init__(self):
        self.gen_count = 0
        self.gen_period = 120   # (unit: frame)0khkhkh
        #### initial with three enemy
        self.reserved_members = [Enemy(),Enemy()]
        self.expedition = [Enemy()]  # don't change this line until you do the EX.3 
        self.ctr = 0

    def generate(self, num):
        #### Generate the enemies in self.reserved_members
        for i in range(num):
            self.reserved_members.append(Enemy())
        """
        Generate the enemies in this wave
        :param num: enemy number
        :return: None
        """

        # ...(to be done)
        pass
    def campaign(self):
        #### Send an enemy to go on an expedition once 120 frame
        self.ctr +=1
        if self.ctr == self.gen_period:
            if len(self.reserved_members) != 0:
                self.expedition.append(self.reserved_members.pop())
            self.ctr = 0
        
        """
        Send an enemy to go on an expedition once 120 frame
        :return: None
        """

        # Hint: self.expedition.append(self.reserved_members.pop())
        # ...(to be done)

        pass

    

    def get(self):
        """
        Get the enemy list
        """
        return self.expedition

    def is_empty(self):
        """
        Return whether the enemy is empty (so that we can move on to next wave)
        """
        return False if self.reserved_members else True

    def retreat(self, enemy):
        """
        Remove the enemy from the expedition
        :param enemy: class Enemy()
        :return: None
        """
        self.expedition.remove(enemy)





